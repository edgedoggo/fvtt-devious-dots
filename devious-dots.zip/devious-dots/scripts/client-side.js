Hooks.once('ready', async function() {
  // Log statement
  console.log("Listening for Devious");

  // Register the socket event handler
  game.socket.on('devious-dots', async (data) => {
    if (data.type === 'predeterminedDots') {
      // Log statement
      console.log("Received Devious Event");

      // Handle the predetermined roll event
      handlePredeterminedRoll(data);
    }
  });
});

function handlePredeterminedDots(data) {
  // Get the actor by ID
  const actor = game.actors.get(data.data.actorId);

  // Modify the next roll on the character sheet
  if (actor) {
    // Replace the next roll with the predetermined outcome
    actor.data.flags.predeterminedDots = data.data.outcome;

    // Display a chat message to inform the player
    ChatMessage.create({
      content: `<h3>${actor.name}'s next roll has been predetermined</h3>` +
               `<p>Predetermined Outcome: ${data.data.outcome}</p>`,
      speaker: ChatMessage.getSpeaker({ actor: actor }),
    });
  }
}
